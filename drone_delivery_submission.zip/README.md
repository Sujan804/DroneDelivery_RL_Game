# Drone Delivery — RL Game Assignment 2

**Name:** MD Sujan Miah  **Student ID:** 251050602  **Reg No:** 60761
**Course:** Reinforcement Learning Game Assignment — Option 2: Drone Delivery

Fly a drone around two fixed obstacles and reach the delivery zone. A DQN agent
is trained from scratch on the game; a saved policy is included.

---

## 1. Game

- Small 2D map (600×400) with **two fixed circular obstacles** and **one delivery
  target**. The first obstacle sits on the straight start→target line, so a
  direct dash is impossible — the drone must fly around it.
- The drone has momentum (velocity with drag), which makes control non-trivial.
- **Objective:** reach the green delivery zone. **Score** is shown on screen.
- **Reset:** every episode auto-resets (new random-free deterministic start);
  in human mode the game restarts after each delivery/crash/timeout.
- **Episode ends** on reaching the target (success), colliding with an obstacle
  (crash), or a 300-step time limit.

## 2. RL formulation

| Part | Choice |
|---|---|
| **Observations** | 6 numbers: normalized x, y, vx, vy, and direction to target (dx, dy) |
| **Actions** | 5 discrete: move left, right, up, down, or hover |
| **Reward** | +100 delivery, −100 crash, −1 per step (rewards finishing fast), −25 timeout, plus small potential-based shaping (0.5 × Δφ) that rewards closing the distance and keeping out of obstacle safety rings |

The shaping is potential-based (Ng, Harada & Russell, 1999), so it speeds up
learning without changing the optimal policy.

**Algorithm: DQN** — MLP Q-network (6 → 128 → 128 → 5), experience replay
(50,000), target network synced every 1,000 learn steps, epsilon-greedy
exploration decaying linearly 1.0 → 0.05 over 700 episodes, Adam (lr 1e-3),
γ = 0.99, batch 128, smooth-L1 loss with gradient clipping.

## 3. Setup

Python 3.10+ (tested on 3.13). Training runs on CPU in a few minutes.

```bash
pip install numpy torch matplotlib   # required for training/evaluation
pip install pygame                   # only needed for the visual demo
```

No other services or data files are needed. All libraries used are acknowledged
in §6.

## 4. How to run

| Command | What it does |
|---|---|
| `python train.py` | Trains the DQN for 1000 episodes. Saves the best policy to `dqn_drone.pth`, the final one to `dqn_drone_last.pth`, plus `training_plot.png` and `training_log.csv`. |
| `python evaluate.py` | Runs **10 episodes with the trained agent** and **10 with a random agent** on the same 10 starting scenarios (same seeds). Prints and saves average reward, deliveries, crashes, avg steps to `evaluation_results.csv`. |
| `python play.py human` | **You fly** with the arrow keys (30 fps). Score and step counter shown on screen. |
| `python play.py agent` | **The saved DQN policy flies** (greedy, no exploration). Episodes auto-reset after each delivery/crash — good for the demo recording. |

A trained policy (`dqn_drone.pth`) is already included, so `evaluate.py` and
`play.py agent` work without retraining.

## 5. Results (this checkpoint)

Training: success rate 0 → 1.00 (avg over 50 episodes) around episode 750;
best checkpoint kept. See `training_plot.png` and `train_console.log`.

10-episode evaluation on identical starting scenarios:

| Agent | Avg reward | Deliveries | Crashes | Avg steps |
|---|---|---|---|---|
| Trained DQN | **+148.1** | **10/10** | 0/10 | 183.0 |
| Random | −332.6 | 0/10 | 0/10 | 300.0 (all time out) |

**One success:** the agent learned to detour around the central obstacle that
blocks the straight path, using the momentum-aware thrust pattern to arrive at
the zone quickly (10/10 deliveries, no crashes).

**One limitation:** the policy is deterministic at eval time and was trained
from a single fixed start position, so it may not generalize to randomized
starts or moving obstacles.

**One improvement:** randomize the drone start (and obstacle placement) during
training, or add Double-DQN, to make the policy robust and reduce the late-run
performance drift visible in the training curve.

## 6. Acknowledgements / reused code

- All game and training code in this repository was written for this
  assignment; no external game environment was used (pure NumPy physics).
- Libraries used: **numpy** (environment/math), **pytorch** (DQN),
  **matplotlib** (plot), **pygame** (optional visualization only).
- The potential-based reward shaping follows Ng, Harada & Russell (1999),
  *"Policy invariance under reward transformations"*.

## 7. Files

```
drone_env.py            Game environment (physics, reward, pygame renderer)
dqn_agent.py            DQN agent (Q-network, replay buffer, target net)
train.py                Training script (saves policy, plot, log)
evaluate.py             10 trained vs 10 random episodes on same seeds
play.py                 Human play / trained-agent visual demo
dqn_drone.pth           Saved best policy (used by evaluate.py / play.py agent)
dqn_drone_last.pth      Final-episode policy (for reference)
training_plot.png       Training reward plot (raw + smoothed)
training_log.csv        Raw per-episode rewards
evaluation_results.csv  10-episode comparison table
train_console.log       Training console output
```
